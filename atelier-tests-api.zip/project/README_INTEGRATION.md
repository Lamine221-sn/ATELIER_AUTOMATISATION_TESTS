# Intégration dans ton dépôt (flask_app.py existant)

1. Copie dans ton dépôt, à la racine (à côté de flask_app.py) :
   `routes_tests.py`, `storage.py`, `scheduled_run.py`, `requirements.txt` (ajoute `requests` s'il manque),
   `API_CHOICE.md`, le dossier `tester/` et `templates/dashboard.html`.
2. Dans `flask_app.py`, ajoute (sans toucher à tes autres routes) :

       from routes_tests import bp as tests_bp
       app.register_blueprint(tests_bp)

3. Sur PythonAnywhere (console Bash) : `pip install --user requests`, puis recharge la web app.
4. Vérifie que ton workflow de déploiement copie bien les sous-dossiers (`tester/`, `templates/`).
5. Teste : /run -> /dashboard -> /health -> /export.json
6. Planification : onglet Tasks de PythonAnywhere,
   commande `python3 /home/riider221/mysite/scheduled_run.py`
   (compte gratuit : 1 fois par jour seulement. Pour 1 run / 5 min, utilise un cron GitHub Actions
   qui appelle https://riider221.pythonanywhere.com/run).
